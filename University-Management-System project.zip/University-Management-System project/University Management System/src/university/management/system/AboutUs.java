package university.management.system;

import java.awt.*;
import javax.swing.*;

public class AboutUs extends JFrame{

	private final JPanel contentPane;

        public static void main(String[] args) {
            new AboutUs().setVisible(true);			
	}
    
        public AboutUs() {
            
            super("About Us - Daffodil International University");
            setBackground(new Color(173, 216, 230));
            setBounds(500, 250, 700, 600);
		
            contentPane = new JPanel();
            setContentPane(contentPane);
            contentPane.setLayout(null);

            JLabel l1 = new JLabel("New label");
            ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/logo.jpg"));
            Image i2 = i1.getImage().getScaledInstance(250, 100,Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            l1 = new JLabel(i3);
            l1.setBounds(400, 40, 250, 100);
            contentPane.add(l1);


            JLabel l3 = new JLabel("DIU University");
            l3.setForeground(new Color(0, 250, 154));
            l3.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 34));
            l3.setBounds(100, 40, 405, 45);
            contentPane.add(l3);

            JLabel l4 = new JLabel("Mangement System");
            l4.setForeground(new Color(127, 255, 0));
            l4.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 34));
            l4.setBounds(70, 90, 405, 40);
            contentPane.add(l4);

            JLabel l5 = new JLabel("v1.0");
            l5.setForeground(new Color(30, 144, 255));
            l5.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
            l5.setBounds(185, 140, 100, 21);
            contentPane.add(l5);


            JLabel l6 = new JLabel("Developed By : Commando's");
            l6.setForeground(new Color(177, 79, 179));
            l6.setFont(new Font("Trebuchet MS", Font.BOLD, 30));
            l6.setBounds(150, 180, 600, 35);
            contentPane.add(l6);

            JLabel l7 = new JLabel("Name : Naimul Huda Walid");
            l7.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
            l7.setBounds(70, 240, 600, 34);
            contentPane.add(l7);

            JLabel l8 = new JLabel("ID : 191-15-12090");
            l8.setForeground(new Color(247, 79, 79));
            l8.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
            l8.setBounds(90, 260, 600, 34);
            contentPane.add(l8);

            JLabel l9 = new JLabel("Name : Abdullah Bin Masud ");
            l9.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
            l9.setBounds(70, 290, 600, 34);
            contentPane.add(l9);
            
           JLabel l20 = new JLabel("ID : 191-15-12278");
           l20.setForeground(new Color(247, 79, 79));
           l20.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
           l20.setBounds(90, 310, 600, 34);
            contentPane.add(l20);
            
            
            
           JLabel l21 = new JLabel("Name : Dewan Babri Bristy");
           l21.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
           l21.setBounds(70, 340, 600, 34);
            contentPane.add(l21);
            
            
           JLabel l22 = new JLabel("ID : 191-15-12191");
           l22.setForeground(new Color(247, 79, 79));
           l22.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
           l22.setBounds(90, 360, 600, 34);
            contentPane.add(l22);
            
            
           JLabel l23 = new JLabel("Name : Nurunnahar Akter Nira");
           l23.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
           l23.setBounds(70, 390, 600, 34);
            contentPane.add(l23);
            
            
           JLabel l24 = new JLabel("ID : 191-15-12066");
           l24.setForeground(new Color(247, 79, 79));
           l24.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
           l24.setBounds(90, 410, 600, 34);
            contentPane.add(l24);
            
            
           JLabel l25 = new JLabel("Name : Pritom Saha");
           l25.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
           l25.setBounds(70, 440, 600, 34);
            contentPane.add(l25);
            
            
           JLabel l26 = new JLabel("ID : 191-15-12306");
           l26.setForeground(new Color(247, 79, 79));
           l26.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
           l26.setBounds(90, 460, 600, 34);
            contentPane.add(l26);
            
            
           JLabel l27 = new JLabel("Email : naimul15-12090@diu.edu.bd");
           l27.setForeground(new Color(47, 79, 79));
           l27.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 18));
           l27.setBounds(70, 510, 600, 34);
            contentPane.add(l27);
           
          
                
                
            contentPane.setBackground(Color.WHITE);
	}
        

}


